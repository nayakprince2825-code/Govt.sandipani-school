
const menuBtn = document.querySelector(".menu-btn");
const nav = document.querySelector(".nav-links");
if(menuBtn && nav){
  menuBtn.addEventListener("click",()=>nav.classList.toggle("open"));
}
const year = document.querySelector("#year");
if(year) year.textContent = new Date().getFullYear();

const current = location.pathname.split("/").pop() || "index.html";
document.querySelectorAll(".nav-links a").forEach(a=>{
  if(a.getAttribute("href")===current) a.classList.add("active");
});

document.querySelectorAll("form").forEach(form=>{
  form.addEventListener("submit",e=>{
    e.preventDefault();
    alert("Thank you! Your message has been recorded for demonstration.");
    form.reset();
  });
});
