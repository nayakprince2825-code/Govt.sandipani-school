# Govt. Sandipani School, Shahdol Website

## Files
- index.html
- about.html
- academics.html
- staff.html
- achievements.html
- gallery.html
- events.html
- notices.html
- contact.html
- css/style.css
- js/script.js
- images/logo.jpg

## GitHub Pages
1. Create a GitHub repository.
2. Upload all files and folders exactly as shown.
3. Go to Settings -> Pages.
4. Under Build and deployment, choose "Deploy from a branch".
5. Select `main` and `/ (root)`, then Save.
6. Open the generated GitHub Pages link.

## Important
Replace sample staff information, contact details, notices and event information with verified official school information before publishing.
